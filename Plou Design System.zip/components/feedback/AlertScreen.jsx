import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Tag } from '../core/Tag.jsx';

export function AlertScreen({
  place, headline = 'Lluvia moderada en 12 min', detail, time = '12:00',
  intensity = 4, size = 'mobile', actions, style, ...rest
}) {
  const mobile = size === 'mobile';
  return (
    <div
      style={{
        position: 'absolute', inset: 0, zIndex: 20,
        background: 'var(--gradient-alert)', color: '#fff',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: 'var(--space-14)', textAlign: 'center', gap: mobile ? 'var(--space-7)' : 'var(--space-8)',
        boxSizing: 'border-box',
        ...style,
      }}
      role="alertdialog"
      {...rest}
    >
      {place ? <Tag tone="onAlert">{place}</Tag> : null}
      <div
        style={{
          width: mobile ? 80 : 90, height: mobile ? 80 : 90, borderRadius: 'var(--radius-circle)',
          background: 'rgba(255,255,255,0.18)', backdropFilter: 'var(--blur-soft)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: 'var(--shadow-bubble-glow)',
        }}
      >
        <Icon name="bell" size={mobile ? 38 : 42} color="#fff" />
      </div>
      <div style={{ fontWeight: 'var(--weight-black)', fontSize: mobile ? '26px' : 'var(--text-alert-title)', lineHeight: 'var(--leading-tight)' }}>{headline}</div>
      {detail ? <div style={{ fontSize: mobile ? 'var(--text-body-xs)' : 'var(--text-body)', opacity: 0.85 }}>{detail}</div> : null}
      <div style={{ fontWeight: 'var(--weight-black)', fontSize: mobile ? 'var(--text-hero-sm)' : 'var(--text-hero)', letterSpacing: 'var(--tracking-tight)', textShadow: '0 4px 20px rgba(0,0,0,0.3)' }}>{time}</div>
      {intensity ? (
        <div style={{ display: 'flex', gap: '5px', alignItems: 'flex-end', height: 28 }}>
          {[8, 14, 20, 28].map((h, i) => (
            <div key={i} style={{ width: 14, height: h, borderRadius: 'var(--radius-bar)', background: i < intensity ? (i === intensity - 1 ? '#fff' : 'rgba(255,255,255,' + (0.3 + i * 0.12) + ')') : 'rgba(255,255,255,0.18)' }} />
          ))}
        </div>
      ) : null}
      {actions ? <div style={{ display: 'flex', gap: 'var(--space-4)', width: '100%', marginTop: 'var(--space-4)' }}>{actions}</div> : null}
    </div>
  );
}
