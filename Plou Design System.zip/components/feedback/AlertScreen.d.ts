export interface AlertScreenProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Place tag at the top. */
  place?: string;
  /** Headline; pass a fragment with <br /> for the two-line mobile form. */
  headline?: React.ReactNode;
  /** Direction / origin line, e.g. "Procedente del suroeste, hacia tu ubicación". */
  detail?: string;
  /** Arrival clock, set in the largest type in the system (58-64px, weight 900). */
  time?: string;
  /** 1-4 filled bars of the intensity staircase. 0 hides it. Default 4. */
  intensity?: number;
  size?: 'mobile' | 'desktop';
  /** Button row — use variant="glass" and variant="onAlert". */
  actions?: React.ReactNode;
}

export declare function AlertScreen(props: AlertScreenProps): JSX.Element;
