The full-screen rain warning — the only place the four-stop dusk gradient (\`--gradient-alert\`) appears, and the only place type reaches 58-64px.

\`\`\`jsx
<AlertScreen
  place="Navata"
  headline="Lluvia moderada en 12 min"
  detail="Procedente del suroeste, hacia tu ubicación"
  time="12:00" intensity={4}
  actions={<>
    <Button variant="glass" block onClick={snooze}>Posponer 10 min</Button>
    <Button variant="onAlert" block onClick={mute}>Silenciar</Button>
  </>}
/>
\`\`\`

Never uses a generic red alert colour — urgency comes from the gradient and the scale of the clock. Positioned \`absolute\`; put it inside a relative frame.
