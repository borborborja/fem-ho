The hero of the Previsión view: a circular gradient bubble with a white condition glyph, beside the temperature in Roboto 900 with -0.02em tracking.

\`\`\`jsx
<TempReadout temp="31°" condition="Despejado" place="Navata" size="desktop" />
\`\`\`

This bubble is usually the view's one gradient accent. On desktop it lives inside a \`<Card>\`; on mobile it sits directly on the app background.
