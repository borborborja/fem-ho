import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function TempReadout({ temp = '31°', condition = 'Despejado', place, icon = 'sun', size = 'mobile', style, ...rest }) {
  const desktop = size === 'desktop';
  const bubble = desktop ? 76 : 64;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: desktop ? 'var(--space-9)' : 'var(--space-7)', ...style }} {...rest}>
      <div
        style={{
          width: bubble, height: bubble, flex: 'none', borderRadius: 'var(--radius-circle)',
          background: 'var(--gradient-brand)', display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: 'var(--shadow-primary-lg)',
        }}
      >
        <Icon name={icon} size={desktop ? 36 : 30} color="var(--on-brand)" />
      </div>
      <div>
        <div style={{ fontWeight: 'var(--weight-black)', fontSize: desktop ? 'var(--text-display)' : 'var(--text-display-sm)', lineHeight: 1, letterSpacing: 'var(--tracking-tight)' }}>{temp}</div>
        <div style={{ fontSize: desktop ? 'var(--text-body)' : 'var(--text-body-xs)', color: 'var(--ink-soft)', marginTop: '2px' }}>
          {condition}{place ? ' · ' + place : ''}
        </div>
      </div>
    </div>
  );
}
