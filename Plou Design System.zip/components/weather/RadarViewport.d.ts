export interface RadarViewportProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Radar tile image. Ships with assets/radar-map-tile.png. */
  image?: string;
  /** Diameter of the dashed watch ring in px. 170 mobile, 260 desktop. */
  radius?: number;
  /** Edge-to-edge inside a phone frame (no radius, no shadow). Default false. */
  fullBleed?: boolean;
  /** Floating glass UI positioned absolutely over the map. */
  children?: React.ReactNode;
}

export declare function RadarViewport(props: RadarViewportProps): JSX.Element;
