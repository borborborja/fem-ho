import React from 'react';
import { Icon } from '../core/Icon.jsx';

// The small glass pills that sit on the radar map: "Leyenda" bottom-left,
// "≡ Capas" bottom-right. Text-only, no icons except the layers bars glyph.
export function MapControls({ items = [], style, ...rest }) {
  return (
    <div style={{ display: 'flex', gap: 'var(--space-3)', ...style }} {...rest}>
      {items.map(it => (
        <button
          key={it.label}
          onClick={it.onClick}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 'var(--space-2)',
            background: 'var(--glass-bg-strong)',
            backdropFilter: 'var(--blur-glass)', WebkitBackdropFilter: 'var(--blur-glass)',
            border: '1px solid var(--glass-border)', borderRadius: 'var(--radius-pill)',
            padding: '9px 16px', color: 'var(--glass-text)', cursor: 'pointer',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-body-xs)', fontWeight: 600,
            whiteSpace: 'nowrap',
          }}
        >
          {it.glyph === 'layers' ? <Icon name="layers" size={14} /> : null}
          {it.label}
        </button>
      ))}
    </div>
  );
}

export function ZoomControl({ onZoomIn, onZoomOut, style, ...rest }) {
  const btn = {
    width: 34, height: 34, border: 'none', cursor: 'pointer',
    background: 'var(--glass-bg-strong)', color: 'var(--glass-text)',
    fontFamily: 'var(--font-sans)', fontSize: 17, fontWeight: 'var(--weight-bold)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  };
  return (
    <div
      style={{
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
        borderRadius: 'var(--radius-input)', border: '1px solid var(--glass-border)',
        backdropFilter: 'var(--blur-glass)', WebkitBackdropFilter: 'var(--blur-glass)',
        ...style,
      }}
      {...rest}
    >
      <button aria-label="Acercar" onClick={onZoomIn} style={{ ...btn, borderBottom: '1px solid var(--glass-border)' }}>+</button>
      <button aria-label="Alejar" onClick={onZoomOut} style={btn}>−</button>
    </div>
  );
}
