export interface TempReadoutProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Formatted temperature including the degree sign, e.g. "31°". */
  temp?: string;
  /** Condition word, e.g. "Despejado". */
  condition?: string;
  /** Appended after a middot. */
  place?: string;
  /** Icon name for the gradient bubble. Default 'sun'. */
  icon?: 'sun' | 'forecast' | 'radar' | 'bell';
  size?: 'mobile' | 'desktop';
}

export declare function TempReadout(props: TempReadoutProps): JSX.Element;
