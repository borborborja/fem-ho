export interface StatTileProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Uppercase metric name, e.g. "SENSACIÓN", "ÍNDICE UV". */
  label: string;
  /** The reading with its unit, e.g. "6 km/h SE", "1018 hPa". */
  value: React.ReactNode;
  /** mobile = 12px pad / 16px value · desktop = 14px pad / 18px value. Default 'mobile'. */
  size?: 'mobile' | 'desktop';
}

export declare function StatTile(props: StatTileProps): JSX.Element;
