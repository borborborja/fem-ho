import React from 'react';

export function StatTile({ label, value, size = 'mobile', style, ...rest }) {
  const desktop = size === 'desktop';
  return (
    <div
      style={{
        background: 'var(--card-bg)', border: '1px solid var(--card-border)',
        borderRadius: 'var(--radius-card-sm)', boxShadow: 'var(--card-shadow)',
        padding: desktop ? 'var(--pad-tile-lg)' : 'var(--pad-tile)', boxSizing: 'border-box',
        ...style,
      }}
      {...rest}
    >
      <div style={{ fontSize: desktop ? '10px' : 'var(--text-micro)', letterSpacing: 'var(--tracking-caps-sm)', color: 'var(--ink-faint)', textTransform: 'uppercase' }}>{label}</div>
      <div style={{ fontWeight: 800, fontSize: desktop ? '18px' : 'var(--text-card-title)', marginTop: desktop ? '4px' : '3px' }}>{value}</div>
    </div>
  );
}
