export interface LocationCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Place name, optionally prefixed with a role: "Casa — Navata". */
  name: string;
  /** "Alarma activa" | "En pausa". */
  status?: string;
  /** Watch radius, e.g. "20 km". */
  meta?: string;
  /** "Débil" | "Moderada" | "Fuerte". */
  intensity?: string;
  /** "Todo el día" | "Día" | "Noche". */
  schedule?: string;
  /** "Automática" | "Banner" | "Pantalla completa" — rendered as the one accent tag. */
  notifType?: string;
  /** Last-alert line, e.g. "Sin avisos todavía". */
  notice?: string;
  /** Status dot colour — cycle --dot-1/2/3 across the list. */
  dot?: string;
  density?: 'mobile' | 'comfy';
  /** Show the Editar / Comprobar row. Default true. */
  actions?: boolean;
  onEdit?: () => void;
  onCheck?: () => void;
  /** When provided, adds the destructive Eliminar button. */
  onDelete?: () => void;
}

export declare function LocationCard(props: LocationCardProps): JSX.Element;
