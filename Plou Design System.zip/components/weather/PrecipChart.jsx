import React from 'react';

// Bars are drawn as 4px stubs when there is no precipitation — Plou never hides
// the axis, it shows an empty one plus a plain-language note.
export function PrecipChart({ title = 'Precipitación prevista (6 h)', data = [], height = 70, note, style, ...rest }) {
  const max = Math.max(1, ...data.map(d => d.value || 0));
  return (
    <div style={style} {...rest}>
      {title ? <div style={{ fontWeight: 'var(--weight-bold)', fontSize: 'var(--text-subtitle)', marginBottom: 'var(--space-4)' }}>{title}</div> : null}
      <div style={{ height, display: 'flex', alignItems: 'flex-end', gap: '5px', borderBottom: '1px solid var(--divider)' }}>
        {data.map((d, i) => {
          const empty = !d.value;
          return (
            <div
              key={i}
              style={{
                flex: 1,
                height: empty ? 4 : Math.max(6, (d.value / max) * height),
                borderRadius: 'var(--radius-bar)',
                background: empty ? 'var(--divider)' : 'var(--gradient-brand-2stop)',
                transition: 'height var(--dur-base) var(--ease-standard)',
              }}
            />
          );
        })}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '10px', color: 'var(--ink-faint)', marginTop: 'var(--space-2)' }}>
        {data.map((d, i) => <span key={i}>{d.time}</span>)}
      </div>
      {note ? <p style={{ fontSize: 'var(--text-label)', color: 'var(--ink-faint)', margin: '10px 0 0' }}>{note}</p> : null}
    </div>
  );
}
