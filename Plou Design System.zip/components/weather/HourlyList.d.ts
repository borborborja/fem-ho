export interface HourlyRow {
  /** "13:00" */
  time: string;
  /** "31°" */
  temp: string;
  /** "6 km/h SE" */
  wind: string;
  /** "Despejado" */
  cond: string;
  /** Icon name for the condition column when showIcon is set. Defaults to 'sun'. */
  icon?: string;
  /** Precipitation for the hour, e.g. "0.4 mm". Falls back to an em dash. */
  precip?: string;
}

export interface HourlyListProps extends React.HTMLAttributes<HTMLDivElement> {
  rows: HourlyRow[];
  /** Uppercase day heading above the rows, e.g. "LUNES · 27 JUL". */
  dayLabel?: string;
  /** Show the condition glyph between time and temperature. */
  showIcon?: boolean;
  /** Show the per-hour precipitation column (em dash when dry). */
  showPrecip?: boolean;
}

export declare function HourlyList(props: HourlyListProps): JSX.Element;
