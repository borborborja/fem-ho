export interface PrecipPoint {
  /** Axis label, e.g. "13:00". */
  time: string;
  /** mm/h. 0 or undefined renders the 4px "no echo" stub. */
  value?: number;
}

export interface PrecipChartProps extends React.HTMLAttributes<HTMLDivElement> {
  title?: string;
  data: PrecipPoint[];
  /** Plot height in px. 70 mobile, 90 desktop. Default 70. */
  height?: number;
  /** Plain-language footnote, e.g. "No se espera precipitación en la ventana analizada." */
  note?: string;
}

export declare function PrecipChart(props: PrecipChartProps): JSX.Element;
