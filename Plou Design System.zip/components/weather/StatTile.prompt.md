Small metric tile — 18px-radius card with an uppercase micro label over a bold value. Always laid out in a 3-column grid.

\`\`\`jsx
<div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8 }}>
  <StatTile label="SENSACIÓN" value="30°" />
  <StatTile label="VIENTO" value="6 km/h SE" />
  <StatTile label="ÍNDICE UV" value="7.0 · Alto" />
</div>
\`\`\`

Plou's nine metrics, in order: sensación, humedad, viento, rachas, presión, nubosidad, visibilidad, índice UV, punto de rocío. Compound values use a middot separator ("7.0 · Alto").
