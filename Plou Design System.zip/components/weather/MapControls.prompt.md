The two glass affordances on the radar map: text pills ("Leyenda", "≡ Capas") and the stacked +/− zoom control.

\`\`\`jsx
<MapControls style={{ position: 'absolute', left: 20, bottom: 84 }} items={[{ label: 'Leyenda', onClick: openLegend }]} />
<MapControls style={{ position: 'absolute', right: 20, bottom: 84 }} items={[{ label: 'Capas', glyph: 'layers', onClick: openLayers }]} />
<ZoomControl style={{ position: 'absolute', left: 20, top: 84 }} onZoomIn={zin} onZoomOut={zout} />
\`\`\`

Both live inside \`<RadarViewport>\` as absolutely-positioned children. ZoomControl is the one control in Plou with a 14px radius instead of a capsule — it is a stacked pair, so it follows the map-control convention, not the pill convention.
