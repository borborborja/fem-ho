Series key under a chart — 10px rounded swatch plus a soft 12px label. Sits between the plot and the axis labels.

\`\`\`jsx
<ChartLegend items={[
  { label: 'Precipitación', color: 'var(--gradient-brand-2stop)' },
  { label: 'Probabilidad', color: 'var(--divider)' },
]} />
\`\`\`

Two series maximum — Plou charts never plot more.
