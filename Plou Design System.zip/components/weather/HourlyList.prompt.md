The "Por horas" table: fixed-width time and temperature columns, then wind flexing, then condition right-aligned. Rows are separated by \`--divider-soft\` hairlines, last row unruled.

\`\`\`jsx
<Card style={{ padding: '8px 20px' }}>
  <div className="plou-eyebrow" style={{ padding: '14px 0 6px' }}>Por horas</div>
  <HourlyList rows={hourly} dayLabel="Lunes · 27 jul" showIcon showPrecip />
</Card>
\`\`\`

\`showIcon\` and \`showPrecip\` add the condition glyph and the mm column from the full Previsión view; omit both for the compact sidebar form. Its host Card uses reduced vertical padding (\`8px 20px\`) so the hairlines reach closer to the card edge.
