Bar chart of forecast precipitation, sitting inside a \`<Card>\`. Empty hours render as 4px neutral stubs rather than disappearing.

\`\`\`jsx
<Card>
  <PrecipChart
    height={90}
    data={[{ time: '13:00' }, { time: '14:00' }, { time: '15:00', value: 0.4 }]}
    note="No se espera precipitación en la ventana analizada."
  />
</Card>
\`\`\`

Bars use the 2-stop blue→pink gradient; the baseline is a \`--divider\` hairline with no gridlines above it.
