One watched location and its rain alarm — the core object of the Alarmas view. Composes Card, Tag and Button.

\`\`\`jsx
<LocationCard
  name="Casa — Navata" status="Alarma activa" meta="10 km"
  intensity="Moderada" schedule="Día" notifType="Pantalla completa"
  notice="Sin avisos todavía" dot="var(--dot-2)"
  onEdit={openEdit} onCheck={openAlert}
/>
\`\`\`

Three per row on desktop, stacked on mobile (where \`onDelete\` is also shown). The status dot cycles \`--dot-1/2/3\` down the list — it is decoration, not severity.
