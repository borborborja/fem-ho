export interface MapControlItem {
  label: string;
  /** 'layers' draws the three-bar glyph before the label. */
  glyph?: 'layers';
  onClick?: () => void;
}

export interface MapControlsProps extends React.HTMLAttributes<HTMLDivElement> {
  items: MapControlItem[];
}

export interface ZoomControlProps extends React.HTMLAttributes<HTMLDivElement> {
  onZoomIn?: () => void;
  onZoomOut?: () => void;
}

export declare function MapControls(props: MapControlsProps): JSX.Element;
export declare function ZoomControl(props: ZoomControlProps): JSX.Element;
