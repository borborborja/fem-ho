import React from 'react';

export function ChartLegend({ items = [], style, ...rest }) {
  return (
    <div style={{ display: 'flex', gap: 'var(--space-7)', flexWrap: 'wrap', ...style }} {...rest}>
      {items.map(it => (
        <div key={it.label} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2)' }}>
          <span style={{ width: 10, height: 10, borderRadius: 3, background: it.color, flex: 'none' }} />
          <span style={{ fontSize: 'var(--text-label)', color: 'var(--ink-soft)' }}>{it.label}</span>
        </div>
      ))}
    </div>
  );
}
