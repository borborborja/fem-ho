import React from 'react';

// The radar map: a dark gradient substrate, the tile screenshot at 55% opacity in
// screen blend, a dashed watch-radius ring and a gradient pin. UI floats on top as children.
export function RadarViewport({ image, radius = 170, fullBleed = false, children, style, ...rest }) {
  return (
    <div
      style={{
        position: 'relative', overflow: 'hidden',
        borderRadius: fullBleed ? 0 : 'var(--radius-panel)',
        boxShadow: fullBleed ? 'none' : 'var(--shadow-map)',
        ...style,
      }}
      {...rest}
    >
      <div style={{ position: 'absolute', inset: 0, background: 'var(--gradient-radar)' }} />
      {image ? (
        <img src={image} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', opacity: 0.55, mixBlendMode: 'screen' }} />
      ) : null}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: radius, height: radius, borderRadius: 'var(--radius-circle)', border: '2px dashed var(--ring-radar)', position: 'relative' }}>
          <div
            style={{
              position: 'absolute', left: '50%', top: '50%',
              width: radius > 200 ? 14 : 12, height: radius > 200 ? 14 : 12,
              borderRadius: 'var(--radius-circle)', background: 'var(--gradient-toggle)',
              transform: 'translate(-50%,-50%)', boxShadow: 'var(--shadow-pin-glow)',
            }}
          />
        </div>
      </div>
      {children}
    </div>
  );
}
