export interface ChartLegendItem {
  label: string;
  /** Any CSS colour or gradient — use --gradient-brand-2stop for the precipitation series. */
  color: string;
}

export interface ChartLegendProps extends React.HTMLAttributes<HTMLDivElement> {
  items: ChartLegendItem[];
}

export declare function ChartLegend(props: ChartLegendProps): JSX.Element;
