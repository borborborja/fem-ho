import React from 'react';
import { Icon } from '../core/Icon.jsx';

export function HourlyList({ rows = [], dayLabel, showIcon, showPrecip, style, ...rest }) {
  return (
    <div style={style} {...rest}>
      {dayLabel ? (
        <div style={{ fontSize: 'var(--text-label)', fontWeight: 'var(--weight-bold)', color: 'var(--ink-faint)', textTransform: 'uppercase', letterSpacing: 'var(--tracking-caps)', padding: '4px 0 8px' }}>{dayLabel}</div>
      ) : null}
      {rows.map((r, i) => (
        <div
          key={i}
          style={{
            display: 'flex', alignItems: 'center', gap: 'var(--space-5)',
            padding: 'var(--space-4) 0',
            borderBottom: i === rows.length - 1 ? 'none' : '1px solid var(--divider-soft)',
          }}
        >
          <span style={{ fontWeight: 800, fontSize: 'var(--text-body-xs)', width: 48 }}>{r.time}</span>
          {showIcon ? <Icon name={r.icon || 'sun'} size={17} style={{ color: 'var(--ink-soft)' }} /> : null}
          <span style={{ fontWeight: 'var(--weight-bold)', fontSize: 'var(--text-body-xs)', width: 34 }}>{r.temp}</span>
          {showPrecip ? (
            <span style={{ fontSize: 'var(--text-label)', color: 'var(--ink-faint)', width: 44 }}>{r.precip || '—'}</span>
          ) : null}
          <span style={{ fontSize: 'var(--text-label)', color: 'var(--ink-faint)', flex: 1 }}>{r.wind}</span>
          <span style={{ fontSize: 'var(--text-label)', color: 'var(--ink-faint)' }}>{r.cond}</span>
        </div>
      ))}
    </div>
  );
}
