import React from 'react';
import { Card } from '../core/Card.jsx';
import { Tag } from '../core/Tag.jsx';
import { Button } from '../core/Button.jsx';

export function LocationCard({
  name, status = 'Alarma activa', meta, intensity, schedule, notifType,
  notice, dot = 'var(--dot-1)', density = 'comfy', actions = true,
  onEdit, onCheck, onDelete, style, ...rest
}) {
  return (
    <Card density={density} style={style} {...rest}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 'var(--space-3)' }}>
        <div style={{ fontWeight: 800, fontSize: 'var(--text-h3)' }}>{name}</div>
        <div style={{ width: 10, height: 10, borderRadius: 'var(--radius-circle)', background: dot, flex: 'none', marginTop: 5 }} />
      </div>
      <div style={{ fontSize: 'var(--text-meta)', color: 'var(--ink-soft)', marginTop: 2 }}>
        {status}{meta ? ' · ' + meta : ''}
      </div>
      {(intensity || schedule || notifType) ? (
        <div style={{ display: 'flex', gap: 'var(--space-2)', flexWrap: 'wrap', marginTop: 'var(--space-5)' }}>
          {intensity ? <Tag size="sm">Intensidad: {intensity}</Tag> : null}
          {schedule ? <Tag size="sm">{schedule}</Tag> : null}
          {notifType ? <Tag size="sm" tone="accent">{notifType}</Tag> : null}
        </div>
      ) : null}
      {notice ? <p style={{ fontSize: 'var(--text-meta)', color: 'var(--ink-faint)', margin: 'var(--space-5) 0' }}>{notice}</p> : null}
      {actions ? (
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <Button variant="ghost" size="md" block onClick={onEdit}>Editar</Button>
          <Button variant="ghost" size="md" block onClick={onCheck}>Comprobar</Button>
          {onDelete ? <Button variant="danger" size="md" block onClick={onDelete}>Eliminar</Button> : null}
        </div>
      ) : null}
    </Card>
  );
}
