The radar map surface. Owns the dark substrate, the tile imagery, the dashed watch radius and the glowing location pin; everything else floats on top as absolutely-positioned children.

\`\`\`jsx
<RadarViewport image="assets/radar-map-tile.png" radius={260} style={{ height: 'calc(100vh - 140px)' }}>
  <GlassBar style={{ position: 'absolute', left: 20, right: 20, bottom: 20 }}>…</GlassBar>
</RadarViewport>
\`\`\`

The map is always dark, in both themes — light-theme screens keep a dark radar. Use \`fullBleed\` when it fills a phone screen.
