const NAV = [
  { value: 'radar', label: 'Radar', icon: 'radar' },
  { value: 'prevision', label: 'Previsión', icon: 'forecast' },
  { value: 'alarmas', label: 'Alarmas', icon: 'bell' },
  { value: 'ajustes', label: 'Ajustes', icon: 'settings' },
];

function Sidebar({ tab, onTab, theme, onTheme, place, alarms, onOpenAlert }) {
  const { Wordmark, NavItem, Icon, SegmentedControl, Card, Button } = window.PlouDesignSystem_093e07;
  return (
    <div style={{ background: 'var(--sidebar-bg)', backdropFilter: 'var(--blur-sidebar)', border: '1px solid var(--card-border)', borderRadius: 'var(--radius-panel)', padding: '24px 16px', display: 'flex', flexDirection: 'column', gap: 6, height: 'fit-content', position: 'sticky', top: 28 }}>
      <div style={{ padding: '8px 12px 20px' }}><Wordmark size={24} /></div>

      {NAV.map(n => (
        <NavItem key={n.value} icon={<Icon name={n.icon} size={19} />} active={tab === n.value} onClick={() => onTab(n.value)}>{n.label}</NavItem>
      ))}

      <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--divider)' }}>
        <div className="plou-eyebrow" style={{ fontSize: 11, color: 'var(--ink-faint)', padding: '0 12px 8px' }}>Tema</div>
        <SegmentedControl block size="sm" options={['Sistema', 'Claro', 'Oscuro']} value={theme} onChange={onTheme} />
      </div>

      {tab === 'radar' ? (
        <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--divider)', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Card tone="washCool" density="tight" kicker="Sin precipitación cerca" title={place} meta="hace 7 min">
            <p style={{ fontSize: 'var(--text-label)', color: 'var(--ink-soft)', margin: '8px 0 10px' }}>No se espera precipitación (0–90 min).</p>
            <Button variant="ghost" block size="sm" onClick={onOpenAlert}>Ver ejemplo de alerta</Button>
          </Card>

          <Card density="tight">
            <div className="plou-eyebrow" style={{ fontSize: 10.5, marginBottom: 10 }}>Mis ubicaciones</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {alarms.map((a, i) => (
                <div key={a.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 0', borderBottom: i === alarms.length - 1 ? 'none' : '1px solid var(--divider-soft)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: a.dot }} />
                    <span style={{ fontSize: 12.5, fontWeight: 600 }}>{a.name}</span>
                  </div>
                  <span style={{ fontSize: 10.5, color: 'var(--ink-faint)' }}>{a.meta}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      ) : null}
    </div>
  );
}
window.Sidebar = Sidebar;
