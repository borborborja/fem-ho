function SettingsPanel() {
  const { Card, SegmentedControl, ChoiceChips, SettingsGroup, SettingsRow, Switch, Slider } = window.PlouDesignSystem_093e07;
  const [lang, setLang] = React.useState('Castellano');
  const [tUnit, setTUnit] = React.useState('°C');
  const [wUnit, setWUnit] = React.useState('km/h');
  const [pUnit, setPUnit] = React.useState('mm');
  const [dUnit, setDUnit] = React.useState('km');
  const [prUnit, setPrUnit] = React.useState('hPa');
  const [scale, setScale] = React.useState('Original');
  const [baseMap, setBaseMap] = React.useState('Según el sistema');
  const [history, setHistory] = React.useState('2 h');
  const [opacity, setOpacity] = React.useState(100);
  const [speed, setSpeed] = React.useState(420);
  const [mm, setMm] = React.useState(true);
  const [awake, setAwake] = React.useState(false);
  const [saver, setSaver] = React.useState(false);
  const [extrapolate, setExtrapolate] = React.useState(true);
  const [smooth, setSmooth] = React.useState(true);
  const [snow, setSnow] = React.useState(true);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, alignItems: 'start' }}>
      <SettingsGroup title="Idioma">
        <SettingsRow>
          <SegmentedControl block options={['Castellano', 'Català', 'English']} value={lang} onChange={setLang} />
        </SettingsRow>
      </SettingsGroup>

      <SettingsGroup title="Unidades">
        <SettingsRow label="Temperatura" inline>
          <SegmentedControl options={['°C', '°F']} value={tUnit} onChange={setTUnit} style={{ width: 110 }} />
        </SettingsRow>
        <SettingsRow label="Viento">
          <ChoiceChips size="sm" options={['km/h', 'm/s', 'mph', 'kn', 'Bft']} value={wUnit} onChange={setWUnit} />
        </SettingsRow>
        <SettingsRow label="Precipitación" inline>
          <SegmentedControl options={['mm', 'in']} value={pUnit} onChange={setPUnit} style={{ width: 110 }} />
        </SettingsRow>
        <SettingsRow label="Distancia" inline>
          <SegmentedControl options={['km', 'mi']} value={dUnit} onChange={setDUnit} style={{ width: 110 }} />
        </SettingsRow>
        <SettingsRow label="Presión">
          <ChoiceChips size="sm" options={['hPa', 'inHg', 'mmHg']} value={prUnit} onChange={setPrUnit} />
        </SettingsRow>
      </SettingsGroup>

      <SettingsGroup title="Aspecto del mapa" style={{ gridColumn: '1 / -1' }}>
        <SettingsRow label="Escala de color">
          <ChoiceChips options={['Blanco y negro', 'Original', 'Azul universal', 'Titan', 'The Weather Channel', 'Meteored', 'NEXRAD nivel III', 'Arcoíris (Selex SI)', 'Dark Sky']} value={scale} onChange={setScale} />
        </SettingsRow>
        <SettingsRow label="Mapa base">
          <ChoiceChips options={['Según el sistema', 'Claro', 'Oscuro', 'OpenStreetMap', 'OpenTopoMap']} value={baseMap} onChange={setBaseMap} />
        </SettingsRow>
        <SettingsRow label="Historia">
          <ChoiceChips size="sm" options={['30 min', '1 h', '2 h']} value={history} onChange={setHistory} />
        </SettingsRow>
        <SettingsRow>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
            <Slider label="Opacidad" valueLabel={opacity + ' %'} min={0} max={100} value={opacity} onChange={setOpacity} />
            <Slider label="Velocidad" valueLabel={speed + ' ms'} min={100} max={1000} step={20} value={speed} onChange={setSpeed} />
          </div>
        </SettingsRow>
        <SettingsRow label="Incluir extrapolación (+30 min)" inline><Switch checked={extrapolate} onChange={setExtrapolate} /></SettingsRow>
        <SettingsRow label="Suavizado" inline><Switch checked={smooth} onChange={setSmooth} /></SettingsRow>
        <SettingsRow label="Distinguir nieve" inline><Switch checked={snow} onChange={setSnow} /></SettingsRow>
      </SettingsGroup>

      <SettingsGroup title="Notificaciones" note="Zona horaria: Europe/Madrid" style={{ gridColumn: '1 / -1' }}>
        <SettingsRow label="Mostrar intensidad en mm/h" inline><Switch checked={mm} onChange={setMm} /></SettingsRow>
        <SettingsRow label="Mantener la pantalla encendida" inline><Switch checked={awake} onChange={setAwake} /></SettingsRow>
        <SettingsRow label="Ahorro de energía" inline><Switch checked={saver} onChange={setSaver} /></SettingsRow>
      </SettingsGroup>

      <Card style={{ gridColumn: '1 / -1' }}>
        <div style={{ fontWeight: 'var(--weight-bold)', fontSize: 'var(--text-subtitle)', marginBottom: 4 }}>Fuentes de datos</div>
        <p style={{ margin: 0, fontSize: 'var(--text-body-xs)', color: 'var(--ink-faint)' }}>Radar: RainViewer · Previsión: Open-Meteo · © Colaboradores de OpenStreetMap</p>
      </Card>
    </div>
  );
}
window.SettingsPanel = SettingsPanel;
