# UI kit — Plou Web (desktop)

Click-through recreation of the desktop Plou app, rebuilt from `Plou Web.dc.html` in the source design project.

## Layout rules this kit encodes
- 28px page padding, `max-width: 1360px`, `grid-template-columns: 248px 1fr` with a 28px gutter.
- The sidebar is glass (`--sidebar-bg` + `--blur-sidebar`), `position: sticky; top: 28px`, `height: fit-content`.
- **Radar** fills the main panel edge-to-edge at `calc(100vh - 140px)`, 28px radius, `--shadow-map`. Status and location cards live *under the sidebar nav*, not floating on the map — that is the one structural difference from mobile.
- **Previsión** is a 1.3fr / 1fr split; **Alarmas** a 3-column card grid; **Ajustes** a 2-column card grid with a full-width notifications card.

## Files
| File | What it is |
| --- | --- |
| `Sidebar.jsx` | Wordmark, four nav rows, theme segmented control, radar-only status + locations cards. |
| `RadarPanel.jsx` | Full-panel radar with search, watch button and playback bar. |
| `ForecastPanel.jsx` | Temperature card, 9 stat tiles, precipitation chart, next-window card, hourly table. |
| `AlarmsPanel.jsx` | 3-up location cards + alert history. |
| `SettingsPanel.jsx` | Language, units and notification cards. |
| `PlouWebShell.jsx` | Shell, routing, theme, alert overlay and edit dialog. |

## Accent

Both kits render with `data-accent="mono-warm"` on the screen root — the single warm orange → pink sweep. Change that one attribute (`PhoneFrame`'s `accent` prop in the app kit, the root `div` in `PlouWebShell.jsx`) to `soft`, `mono-cool`, or drop it for the default sunset triad; nothing else needs touching.

## What you can click
Sidebar nav · theme switcher (live light/dark) · play/pause on the radar · **Ver ejemplo de alerta** / **Comprobar** → full-screen alert · **Editar** → alarm dialog · every segmented control and switch in Ajustes.
