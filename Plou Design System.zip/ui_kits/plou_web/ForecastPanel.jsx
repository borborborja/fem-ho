const STATS = [
  ['SENSACIÓN', '30°'], ['HUMEDAD', '32 %'], ['VIENTO', '6 km/h SE'],
  ['RACHAS', '22 km/h'], ['PRESIÓN', '1018 hPa'], ['NUBOSIDAD', '0 %'],
  ['VISIBILIDAD', '44 km'], ['ÍNDICE UV', '7.0 · Alto'], ['PUNTO DE ROCÍO', '13°'],
];

function ForecastPanel({ place, hourly }) {
  const { Card, TempReadout, StatTile, PrecipChart, ChartLegend, HourlyList, Tag } = window.PlouDesignSystem_093e07;
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 22 }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <Card><TempReadout size="desktop" temp="31°" condition="Despejado" place={place} /></Card>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12 }}>
          {STATS.map(([l, v]) => <StatTile key={l} size="desktop" label={l} value={v} />)}
        </div>

        <Card>
          <PrecipChart height={90} title="Precipitación prevista (6 h)" data={hourly.map(h => ({ time: h.time }))} />
          <ChartLegend style={{ marginTop: 12 }} items={[{ label: 'Precipitación', color: 'var(--gradient-brand-2stop)' }, { label: 'Probabilidad', color: 'var(--divider)' }]} />
        </Card>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
        <Card tone="washWarm" kicker="Próxima ventana" title={<span style={{ fontSize: 'var(--text-h2)' }}>Sin lluvia hasta las 19:40</span>}>
          <p style={{ fontSize: 'var(--text-body-xs)', color: 'var(--ink-soft)', margin: '8px 0 10px' }}>Franja despejada estable durante las próximas 6 horas. Buen momento para salir sin paraguas.</p>
          <Tag>Se abre en 6h 20min</Tag>
        </Card>

        <Card style={{ padding: '8px 20px' }}>
          <div className="plou-eyebrow" style={{ padding: '14px 0 6px' }}>Por horas</div>
          <HourlyList rows={hourly} dayLabel="Lunes · 27 jul" showIcon showPrecip />
        </Card>
      </div>
    </div>
  );
}
window.ForecastPanel = ForecastPanel;
