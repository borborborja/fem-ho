function RadarPanel({ playing, onTogglePlay }) {
  const { RadarViewport, GlassBar, TextField, Button, IconButton, Icon, Slider, MapControls, ZoomControl } = window.PlouDesignSystem_093e07;
  return (
    <RadarViewport image="../../assets/radar-map-tile.png" radius={260} style={{ height: 'calc(100vh - 140px)', minHeight: 640 }}>
      <div style={{ position: 'absolute', top: 20, left: 20, display: 'flex', gap: 10, zIndex: 2 }}>
        <TextField tone="glass" shape="pill" placeholder="Buscar lugar…" style={{ width: 300, flex: 'none' }} />
        <Button>+ Vigilar este punto</Button>
      </div>

      <ZoomControl style={{ position: 'absolute', left: 20, top: 84, zIndex: 2 }} />

      <MapControls style={{ position: 'absolute', left: 20, bottom: 88, zIndex: 2 }} items={[{ label: 'Leyenda' }]} />
      <MapControls style={{ position: 'absolute', right: 20, bottom: 88, zIndex: 2 }} items={[{ label: 'Capas', glyph: 'layers' }]} />

      <GlassBar style={{ position: 'absolute', left: 20, right: 20, bottom: 20, gap: 14, padding: '10px 16px', zIndex: 2 }}>
        <IconButton tone="gradient" size={38} label={playing ? 'Pausar' : 'Reproducir'} onClick={onTogglePlay}>
          <Icon name={playing ? 'pause' : 'play'} size={13} />
        </IconButton>
        <Slider value={70} onChange={() => {}} />
        <div style={{ textAlign: 'right', flex: 'none' }}>
          <div style={{ fontWeight: 900, fontSize: 14 }}>11:40</div>
          <div style={{ fontSize: 10, color: 'var(--glass-text-faint)' }}>−120 min</div>
        </div>
      </GlassBar>
    </RadarViewport>
  );
}
window.RadarPanel = RadarPanel;
