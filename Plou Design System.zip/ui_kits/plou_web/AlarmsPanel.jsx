function AlarmsPanel({ alarms, onEdit, onCheck }) {
  const { Button, LocationCard, Card } = window.PlouDesignSystem_093e07;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div className="plou-eyebrow" style={{ fontSize: 13 }}>Mis ubicaciones</div>
        <Button>+ Añadir ubicación</Button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 16 }}>
        {alarms.map(a => <LocationCard key={a.name} {...a} notifType={undefined} onEdit={onEdit} onCheck={onCheck} />)}
      </div>

      <Card>
        <div style={{ fontWeight: 'var(--weight-bold)', fontSize: 'var(--text-subtitle)', marginBottom: 6 }}>Historial de avisos</div>
        <p style={{ margin: 0, fontSize: 'var(--text-body-xs)', color: 'var(--ink-faint)' }}>Todavía no se ha emitido ningún aviso.</p>
      </Card>
    </div>
  );
}
window.AlarmsPanel = AlarmsPanel;
