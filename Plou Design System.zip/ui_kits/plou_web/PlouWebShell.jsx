const TITLES = { radar: 'Radar', prevision: 'Previsión', alarmas: 'Alarmas', ajustes: 'Ajustes' };

const HOURLY = [
  { time: '13:00', temp: '31°', wind: '5 km/h SE', cond: 'Despejado' },
  { time: '14:00', temp: '31°', wind: '6 km/h ESE', cond: 'Despejado' },
  { time: '15:00', temp: '33°', wind: '8 km/h SE', cond: 'Despejado' },
  { time: '16:00', temp: '33°', wind: '24 km/h SE', cond: 'Despejado' },
  { time: '17:00', temp: '32°', wind: '18 km/h SE', cond: 'Despejado' },
  { time: '18:00', temp: '30°', wind: '14 km/h S', cond: 'Despejado' },
];

const ALARMS = [
  { name: 'Cornellà del Terri', status: 'Alarma activa', meta: '20 km', intensity: 'Débil', schedule: 'Todo el día', notice: 'Sin avisos todavía', dot: 'var(--dot-1)' },
  { name: 'Casa — Navata', status: 'Alarma activa', meta: '10 km', intensity: 'Moderada', schedule: 'Día', notice: 'Sin avisos todavía', dot: 'var(--dot-2)' },
  { name: 'Trabajo — Figueres', status: 'En pausa', meta: '15 km', intensity: 'Fuerte', schedule: 'Noche', notice: 'Última alerta hace 3 días', dot: 'var(--dot-3)' },
];

function PlouWeb() {
  const { Sidebar, RadarPanel, ForecastPanel, AlarmsPanel, SettingsPanel } = window;
  const { Dialog, AlertScreen, Button, TextField, SegmentedControl } = window.PlouDesignSystem_093e07;
  const [tab, setTab] = React.useState('radar');
  const [themePick, setThemePick] = React.useState('Claro');
  const [playing, setPlaying] = React.useState(true);
  const [alert, setAlert] = React.useState(false);
  const [edit, setEdit] = React.useState(false);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = themePick === 'Sistema' ? (prefersDark ? 'dark' : 'light') : (themePick === 'Oscuro' ? 'dark' : 'light');
  const place = 'Navata';

  return (
    <div data-theme={theme} data-accent="mono-warm" style={{ position: 'relative', minHeight: '100vh', background: 'var(--page-bg)', color: 'var(--ink)', fontFamily: 'var(--font-sans)', display: 'flex', justifyContent: 'center', padding: 28, boxSizing: 'border-box' }}>
      <div style={{ width: '100%', maxWidth: 'var(--content-max)', display: 'grid', gridTemplateColumns: 'var(--sidebar-width) 1fr', gap: 28 }}>
        <Sidebar tab={tab} onTab={setTab} theme={themePick} onTheme={setThemePick} place={place} alarms={ALARMS} onOpenAlert={() => setAlert(true)} />

        <div style={{ minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 20 }}>
            <div style={{ fontWeight: 'var(--weight-black)', fontSize: 'var(--text-section)' }}>{TITLES[tab]}</div>
            <div style={{ fontSize: 'var(--text-body)', color: 'var(--ink-soft)' }}>· {place}</div>
          </div>

          {tab === 'radar' ? <RadarPanel playing={playing} onTogglePlay={() => setPlaying(p => !p)} /> : null}
          {tab === 'prevision' ? <ForecastPanel place={place} hourly={HOURLY} /> : null}
          {tab === 'alarmas' ? <AlarmsPanel alarms={ALARMS} onEdit={() => setEdit(true)} onCheck={() => setAlert(true)} /> : null}
          {tab === 'ajustes' ? <SettingsPanel /> : null}
        </div>
      </div>

      {alert ? (
        <AlertScreen size="desktop" place={place} headline="Lluvia moderada en 12 min"
          detail={'Procedente del suroeste, hacia ' + place} time="12:00" intensity={0}
          style={{ position: 'fixed' }}
          actions={<Button variant="onAlert" onClick={() => setAlert(false)} style={{ margin: '0 auto' }}>Silenciar</Button>} />
      ) : null}

      {edit ? (
        <Dialog title="Editar alarma" onClose={() => setEdit(false)} style={{ position: 'relative' }}
          footer={<>
            <Button variant="ghost" block onClick={() => setEdit(false)}>Cancelar</Button>
            <Button block onClick={() => setEdit(false)}>Guardar</Button>
          </>}>
          <TextField label="Nombre de la ubicación" defaultValue="Cornellà del Terri" />
          <div>
            <div style={{ fontSize: 'var(--text-tag)', color: 'var(--ink-soft)', marginBottom: 5 }}>Intensidad mínima</div>
            <SegmentedControl block options={['Débil', 'Moderada', 'Fuerte']} value="Débil" />
          </div>
        </Dialog>
      ) : null}
    </div>
  );
}
window.PlouWeb = PlouWeb;
