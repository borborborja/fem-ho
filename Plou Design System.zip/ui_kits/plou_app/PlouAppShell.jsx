function PlouApp() {
  const { Wordmark, IconButton, Icon, TabBar, Dialog, AlertScreen, Button, TextField, Slider, SegmentedControl } = window.PlouDesignSystem_093e07;
  const { PhoneFrame, RadarScreen, ForecastScreen, AlarmsScreen, SettingsScreen } = window;
  const TABS = [
    { value: 'radar', label: 'Radar', icon: <Icon name="radar" /> },
    { value: 'prevision', label: 'Previsión', icon: <Icon name="forecast" /> },
    { value: 'alarmas', label: 'Alarmas', icon: <Icon name="bell" /> },
    { value: 'ajustes', label: 'Ajustes', icon: <Icon name="settings" /> },
  ];
  const [tab, setTab] = React.useState('radar');
  const [themePick, setThemePick] = React.useState('Claro');
  const [playing, setPlaying] = React.useState(true);
  const [alert, setAlert] = React.useState(false);
  const [edit, setEdit] = React.useState(false);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = themePick === 'Sistema' ? (prefersDark ? 'dark' : 'light') : (themePick === 'Oscuro' ? 'dark' : 'light');
  const place = 'Navata';

  return (
    <PhoneFrame theme={theme} accent="mono-warm">
      {tab === 'radar' ? (
        <RadarScreen place={place} playing={playing} onTogglePlay={() => setPlaying(p => !p)} onOpenAlert={() => setAlert(true)} />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '20px 20px 14px', flex: 'none' }}>
            <Wordmark size={22} place={place} style={{ flex: 1 }} />
            <IconButton label="Mi ubicación"><Icon name="crosshair" size={17} /></IconButton>
          </div>
          <div className="plou-scroll" style={{ flex: 1, overflow: 'auto', padding: '6px 18px 104px' }}>
            {tab === 'prevision' ? <ForecastScreen place={place} /> : null}
            {tab === 'alarmas' ? <AlarmsScreen onEdit={() => setEdit(true)} onCheck={() => setAlert(true)} /> : null}
            {tab === 'ajustes' ? <SettingsScreen theme={themePick} onTheme={setThemePick} /> : null}
          </div>
        </div>
      )}

      <TabBar tabs={TABS} value={tab} onChange={setTab} />

      {alert ? (
        <AlertScreen
          place={place}
          headline={<>Lluvia moderada<br />en 12 min</>}
          detail="Procedente del suroeste, hacia tu ubicación"
          time="12:00"
          actions={<>
            <Button variant="glass" size="md" block onClick={() => setAlert(false)}>Posponer 10 min</Button>
            <Button variant="onAlert" size="md" block onClick={() => setAlert(false)}>Silenciar</Button>
          </>}
        />
      ) : null}

      {edit ? (
        <Dialog title="Editar alarma" width={999} onClose={() => setEdit(false)} style={{ borderRadius: 'var(--radius-dialog)', padding: 22 }}
          footer={<>
            <Button variant="ghost" size="md" block onClick={() => setEdit(false)}>Cancelar</Button>
            <Button size="md" block onClick={() => setEdit(false)}>Guardar</Button>
          </>}>
          <TextField label="Nombre de la ubicación" defaultValue="Cornellà del Terri" />
          <Slider label="Radio de vigilancia" valueLabel="20 km" min={5} max={50} defaultValue={20} />
          <div>
            <div style={{ fontSize: 'var(--text-tag)', color: 'var(--ink-soft)', marginBottom: 5 }}>Intensidad mínima</div>
            <SegmentedControl block size="mobile" options={['Débil', 'Moderada', 'Fuerte']} value="Débil" />
          </div>
          <div>
            <div style={{ fontSize: 'var(--text-tag)', color: 'var(--ink-soft)', marginBottom: 5 }}>Horario activo</div>
            <SegmentedControl block size="mobile" options={['Todo el día', 'Día', 'Noche']} value="Todo el día" />
          </div>
          <div>
            <div style={{ fontSize: 'var(--text-tag)', color: 'var(--ink-soft)', marginBottom: 5 }}>Tipo de notificación</div>
            <SegmentedControl block size="mobile" options={['Automática', 'Banner', 'Pantalla completa']} value="Automática" />
          </div>
        </Dialog>
      ) : null}
    </PhoneFrame>
  );
}
window.PlouApp = PlouApp;
