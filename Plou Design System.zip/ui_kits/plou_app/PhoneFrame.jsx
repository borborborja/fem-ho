// Minimal Android device shell: bezel, status bar, gesture pill.
function PhoneFrame({ width = 390, height = 844, theme = 'light', accent = 'mono-warm', children }) {
  const dark = theme === 'dark';
  return (
    <div style={{ width: width + 22, height: height + 22, borderRadius: 54, padding: 11, background: dark ? '#1b1c22' : '#22242b', boxShadow: '0 30px 70px rgba(20,20,40,0.35)', boxSizing: 'border-box' }}>
      <div data-theme={theme} data-accent={accent} style={{ position: 'relative', width, height, borderRadius: 44, overflow: 'hidden', background: 'var(--app-bg)', color: 'var(--ink)' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 22px', fontSize: 11, fontWeight: 700, color: dark ? 'rgba(255,255,255,0.8)' : 'rgba(20,22,30,0.65)', zIndex: 40, pointerEvents: 'none' }}>
          <span>11:47</span>
          <span style={{ letterSpacing: 2 }}>▪ ▪ ▮</span>
        </div>
        <div style={{ position: 'absolute', inset: '30px 0 0 0' }}>{children}</div>
        <div style={{ position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)', width: 110, height: 4, borderRadius: 4, background: dark ? 'rgba(255,255,255,0.3)' : 'rgba(20,22,30,0.25)', zIndex: 40 }} />
      </div>
    </div>
  );
}
window.PhoneFrame = PhoneFrame;
