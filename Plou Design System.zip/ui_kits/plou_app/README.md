# UI kit — Plou App (Android)

Click-through recreation of the four-tab Plou mobile app, rebuilt from `Plou App.dc.html` in the source design project.

## Screens
| File | What it is |
| --- | --- |
| `PhoneFrame.jsx` | Device bezel, status bar, gesture pill. Sets `data-theme` on the screen. |
| `RadarScreen.jsx` | Radar tab — full-bleed map with glass header, search, watch button, playback bar and status sheet. |
| `ForecastScreen.jsx` | Previsión tab — temperature hero, 9 stat tiles, "próxima ventana" card, precipitation chart, hourly table. |
| `AlarmsScreen.jsx` | Alarmas tab — watched-location cards and the (empty) alert history. |
| `SettingsScreen.jsx` | Ajustes tab — language, theme, units, three switches, data-source note. |
| `PlouAppShell.jsx` | Shell: tab state, theme switch, full-screen alert, edit-alarm dialog. |

## What you can click
Bottom switcher moves between tabs · play/pause on the radar playback bar · **Ver ejemplo de alerta** and **Comprobar** open the full-screen rain alert · **Editar** opens the alarm dialog · Ajustes → Tema switches light/dark live.

## Accent

Both kits render with `data-accent="mono-warm"` on the screen root — the single warm orange → pink sweep. Change that one attribute (`PhoneFrame`'s `accent` prop in the app kit, the root `div` in `PlouWebShell.jsx`) to `soft`, `mono-cool`, or drop it for the default sunset triad; nothing else needs touching.

## Notes
The radar tile image is the real product screenshot (`assets/radar-map-tile.png`) at 55% opacity in `screen` blend, matching the source. The map stays dark in the light theme.
