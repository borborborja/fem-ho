const STATS = [
  ['SENSACIÓN', '30°'], ['HUMEDAD', '32 %'], ['VIENTO', '6 km/h SE'],
  ['RACHAS', '22 km/h'], ['PRESIÓN', '1018 hPa'], ['NUBOSIDAD', '0 %'],
  ['VISIBILIDAD', '44 km'], ['ÍNDICE UV', '7.0 · Alto'], ['PUNTO DE ROCÍO', '13°'],
];

const HOURLY = [
  { time: '13:00', temp: '31°', wind: '5 km/h SE', cond: 'Despejado' },
  { time: '14:00', temp: '31°', wind: '6 km/h ESE', cond: 'Despejado' },
  { time: '15:00', temp: '33°', wind: '8 km/h SE', cond: 'Despejado' },
  { time: '16:00', temp: '33°', wind: '24 km/h SE', cond: 'Despejado' },
  { time: '17:00', temp: '32°', wind: '18 km/h SE', cond: 'Despejado' },
  { time: '18:00', temp: '30°', wind: '14 km/h S', cond: 'Despejado' },
];

function ForecastScreen({ place }) {
  const { TempReadout, StatTile, Card, Tag, PrecipChart, ChartLegend, HourlyList } = window.PlouDesignSystem_093e07;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <TempReadout temp="31°" condition="Despejado" place={place} />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
        {STATS.map(([l, v]) => <StatTile key={l} label={l} value={v} />)}
      </div>

      <Card tone="washCool" density="mobile" kicker="Próxima ventana" title="Sin lluvia hasta las 19:40">
        <p style={{ fontSize: 'var(--text-body-xs)', color: 'var(--ink-soft)', margin: '6px 0 10px' }}>Franja despejada estable durante las próximas 6 horas. Buen momento para salir sin paraguas.</p>
        <Tag size="sm">Se abre en 6h 20min</Tag>
      </Card>

      <Card density="mobile">
        <PrecipChart data={HOURLY.map(h => ({ time: h.time }))} note="No se espera precipitación en la ventana analizada." />
        <ChartLegend style={{ marginTop: 10 }} items={[{ label: 'Precipitación', color: 'var(--gradient-brand-2stop)' }, { label: 'Probabilidad', color: 'var(--divider)' }]} />
      </Card>

      <div>
        <div className="plou-eyebrow" style={{ marginBottom: 8 }}>Por horas</div>
        <Card density="mobile" style={{ padding: '6px 16px' }}><HourlyList rows={HOURLY} dayLabel="Lunes · 27 jul" showIcon showPrecip /></Card>
      </div>
    </div>
  );
}
window.ForecastScreen = ForecastScreen;
window.PLOU_HOURLY = HOURLY;
