const ALARMS = [
  { name: 'Cornellà del Terri', status: 'Alarma activa', meta: '20 km', intensity: 'Débil', schedule: 'Todo el día', notifType: 'Automática', notice: 'Sin avisos todavía', dot: 'var(--dot-1)' },
  { name: 'Casa — Navata', status: 'Alarma activa', meta: '10 km', intensity: 'Moderada', schedule: 'Día', notifType: 'Pantalla completa', notice: 'Sin avisos todavía', dot: 'var(--dot-2)' },
  { name: 'Trabajo — Figueres', status: 'En pausa', meta: '15 km', intensity: 'Fuerte', schedule: 'Noche', notifType: 'Banner', notice: 'Última alerta hace 3 días', dot: 'var(--dot-3)' },
];

function AlarmsScreen({ onEdit, onCheck }) {
  const { Button, LocationCard, Card } = window.PlouDesignSystem_093e07;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div className="plou-eyebrow">Mis ubicaciones</div>
        <Button size="sm">+ Añadir</Button>
      </div>

      {ALARMS.map(a => (
        <LocationCard key={a.name} density="mobile" {...a} onEdit={onEdit} onCheck={onCheck} onDelete={() => {}} />
      ))}

      <div>
        <div className="plou-eyebrow" style={{ marginBottom: 8 }}>Historial de avisos</div>
        <Card density="mobile"><p style={{ margin: 0, fontSize: 'var(--text-body-xs)', color: 'var(--ink-faint)' }}>Todavía no se ha emitido ningún aviso.</p></Card>
      </div>
    </div>
  );
}
window.AlarmsScreen = AlarmsScreen;
window.PLOU_ALARMS = ALARMS;
