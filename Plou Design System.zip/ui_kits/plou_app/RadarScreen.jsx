function RadarScreen({ place, playing, onTogglePlay, onOpenAlert }) {
  const { Wordmark, IconButton, Icon, Tag, Button, TextField, Slider, GlassBar, Card, RadarViewport, MapControls, ZoomControl } = window.PlouDesignSystem_093e07;
  return (
    <RadarViewport image="../../assets/radar-map-tile.png" radius={170} fullBleed style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '18px 18px 40px', background: 'linear-gradient(180deg,rgba(10,10,16,0.55),transparent)', display: 'flex', alignItems: 'center', gap: 10, zIndex: 2 }}>
        <Wordmark tone="white" size={21} place={place} style={{ flex: 1 }} />
        <IconButton tone="glass" label="Mi ubicación"><Icon name="crosshair" size={16} /></IconButton>
      </div>

      <div style={{ position: 'absolute', top: 64, left: 16, right: 16, display: 'flex', gap: 8, zIndex: 2 }}>
        <TextField tone="glass" shape="pill" placeholder="Buscar lugar…" />
        <IconButton tone="glassOutlined" label="Buscar"><Icon name="search" size={16} /></IconButton>
      </div>

      <Tag tone="glass" style={{ position: 'absolute', top: 118, left: 16, zIndex: 2 }}>Sin ecos de precipitación</Tag>
      <Button size="sm" style={{ position: 'absolute', top: 112, right: 16, zIndex: 2 }}>+ Vigilar</Button>

      <ZoomControl style={{ position: 'absolute', left: 16, top: 160, zIndex: 2 }} />

      <MapControls style={{ position: 'absolute', left: 16, bottom: 224, zIndex: 2 }} items={[{ label: 'Leyenda' }]} />
      <MapControls style={{ position: 'absolute', right: 16, bottom: 224, zIndex: 2 }} items={[{ label: 'Capas', glyph: 'layers' }]} />

      <GlassBar style={{ position: 'absolute', left: 16, right: 16, bottom: 172, zIndex: 2 }}>
        <IconButton tone="gradient" size={34} label={playing ? 'Pausar' : 'Reproducir'} onClick={onTogglePlay}>
          <Icon name={playing ? 'pause' : 'play'} size={12} />
        </IconButton>
        <Slider value={70} onChange={() => {}} />
        <div style={{ textAlign: 'right', flex: 'none' }}>
          <div style={{ fontWeight: 900, fontSize: 13 }}>11:40</div>
          <div style={{ fontSize: 9, color: 'var(--glass-text-faint)' }}>−120 min</div>
        </div>
      </GlassBar>

      <div style={{ position: 'absolute', left: 16, right: 16, bottom: 92, zIndex: 2 }}>
        <Card tone="glass" density="tight" kicker="Sin precipitación cerca" title={place} meta="hace 7 min">
          <Button variant="ghost" block size="md" onClick={onOpenAlert} style={{ marginTop: 8, background: 'rgba(20,22,30,0.06)', color: '#14151a' }}>Ver ejemplo de alerta</Button>
        </Card>
      </div>
    </RadarViewport>
  );
}
window.RadarScreen = RadarScreen;
