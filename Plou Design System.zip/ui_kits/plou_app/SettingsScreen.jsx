function SettingsScreen({ theme, onTheme }) {
  const { SegmentedControl, ChoiceChips, SettingsGroup, SettingsRow, Switch, Slider, Card } = window.PlouDesignSystem_093e07;
  const [lang, setLang] = React.useState('Castellano');
  const [tUnit, setTUnit] = React.useState('°C');
  const [wUnit, setWUnit] = React.useState('km/h');
  const [pUnit, setPUnit] = React.useState('mm');
  const [dUnit, setDUnit] = React.useState('km');
  const [scale, setScale] = React.useState('Original');
  const [baseMap, setBaseMap] = React.useState('Según el sistema');
  const [history, setHistory] = React.useState('2 h');
  const [opacity, setOpacity] = React.useState(100);
  const [speed, setSpeed] = React.useState(420);
  const [mm, setMm] = React.useState(true);
  const [awake, setAwake] = React.useState(false);
  const [saver, setSaver] = React.useState(false);
  const [extrapolate, setExtrapolate] = React.useState(true);
  const [smooth, setSmooth] = React.useState(true);
  const [snow, setSnow] = React.useState(true);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <div className="plou-eyebrow" style={{ marginBottom: 8 }}>Idioma</div>
        <SegmentedControl block size="mobile" options={['Castellano', 'Català', 'English']} value={lang} onChange={setLang} />
      </div>

      <div>
        <div className="plou-eyebrow" style={{ marginBottom: 8 }}>Tema</div>
        <SegmentedControl block size="mobile" options={['Sistema', 'Claro', 'Oscuro']} value={theme} onChange={onTheme} />
      </div>

      <SettingsGroup title="Unidades" density="mobile">
        <SettingsRow label="Temperatura" inline>
          <SegmentedControl size="mobile" options={['°C', '°F']} value={tUnit} onChange={setTUnit} style={{ width: 110 }} />
        </SettingsRow>
        <SettingsRow label="Viento">
          <ChoiceChips size="sm" options={['km/h', 'm/s', 'mph', 'kn', 'Bft']} value={wUnit} onChange={setWUnit} />
        </SettingsRow>
        <SettingsRow label="Precipitación" inline>
          <SegmentedControl size="mobile" options={['mm', 'in']} value={pUnit} onChange={setPUnit} style={{ width: 110 }} />
        </SettingsRow>
        <SettingsRow label="Distancia" inline>
          <SegmentedControl size="mobile" options={['km', 'mi']} value={dUnit} onChange={setDUnit} style={{ width: 110 }} />
        </SettingsRow>
      </SettingsGroup>

      <SettingsGroup title="Aspecto del mapa" density="mobile">
        <SettingsRow label="Escala de color">
          <ChoiceChips size="sm" options={['Blanco y negro', 'Original', 'Azul universal', 'Titan', 'The Weather Channel', 'Meteored', 'NEXRAD nivel III', 'Arcoíris (Selex SI)', 'Dark Sky']} value={scale} onChange={setScale} />
        </SettingsRow>
        <SettingsRow label="Mapa base">
          <ChoiceChips size="sm" options={['Según el sistema', 'Claro', 'Oscuro', 'OpenStreetMap', 'OpenTopoMap']} value={baseMap} onChange={setBaseMap} />
        </SettingsRow>
        <SettingsRow>
          <Slider label="Opacidad" valueLabel={opacity + ' %'} min={0} max={100} value={opacity} onChange={setOpacity} />
        </SettingsRow>
        <SettingsRow label="Historia">
          <ChoiceChips size="sm" options={['30 min', '1 h', '2 h']} value={history} onChange={setHistory} />
        </SettingsRow>
        <SettingsRow label="Incluir extrapolación (+30 min)" inline>
          <Switch checked={extrapolate} onChange={setExtrapolate} />
        </SettingsRow>
        <SettingsRow>
          <Slider label="Velocidad" valueLabel={speed + ' ms'} min={100} max={1000} step={20} value={speed} onChange={setSpeed} />
        </SettingsRow>
        <SettingsRow label="Suavizado" inline><Switch checked={smooth} onChange={setSmooth} /></SettingsRow>
        <SettingsRow label="Distinguir nieve" inline><Switch checked={snow} onChange={setSnow} /></SettingsRow>
      </SettingsGroup>

      <SettingsGroup title="Notificaciones" note="Zona horaria: Europe/Madrid" density="mobile">
        <SettingsRow label="Mostrar intensidad en mm/h" inline><Switch checked={mm} onChange={setMm} /></SettingsRow>
        <SettingsRow label="Mantener la pantalla encendida" inline><Switch checked={awake} onChange={setAwake} /></SettingsRow>
        <SettingsRow label="Ahorro de energía" inline><Switch checked={saver} onChange={setSaver} /></SettingsRow>
      </SettingsGroup>

      <Card density="mobile">
        <div style={{ fontWeight: 'var(--weight-bold)', fontSize: 'var(--text-body)', marginBottom: 4 }}>Fuentes de datos</div>
        <p style={{ margin: 0, fontSize: 'var(--text-label)', color: 'var(--ink-faint)' }}>Radar: RainViewer · Previsión: Open-Meteo · © Colaboradores de OpenStreetMap</p>
      </Card>
    </div>
  );
}
window.SettingsScreen = SettingsScreen;
